package com.example.inventoryapp

data class
InventoryItem(
    val id: Int,
    val name: String,
    val quantity: Int,
    val date: String
)
