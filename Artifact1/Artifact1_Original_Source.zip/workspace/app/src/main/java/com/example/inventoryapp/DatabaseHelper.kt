package com.example.inventoryapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "InventoryApp.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {

        // Table for user login info
        db.execSQL("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT
            )
        """)
        db.execSQL("""
        CREATE TABLE inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            quantity INTEGER,
            date TEXT
        )
    """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }

    // Create a new user
    fun createUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put("username", username)
        values.put("password", password)

        val result = db.insert("users", null, values)
        return result != -1L
    }

    // Add item to inventory
    fun addItem(name: String, quantity: Int, date: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", name)
        values.put("quantity", quantity)
        values.put("date", date)
        db.insert("inventory", null, values)
    }

    // Get all inventory items
    fun getAllItems() =
        readableDatabase.rawQuery("SELECT * FROM inventory", null)

    // Delete inventory item
    fun deleteItem(id: Int) {
        writableDatabase.delete("inventory", "id=?", arrayOf(id.toString()))
    }


    // Check login credentials
    fun validateUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE username=? AND password=?",
            arrayOf(username, password)
        )

        val isValid = cursor.count > 0
        cursor.close()
        return isValid
    }
}
