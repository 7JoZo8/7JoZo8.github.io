package com.example.inventoryapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class InventoryActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: InventoryAdapter
    private val items = mutableListOf<InventoryItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)


        db = DatabaseHelper(this)

        val nameInput = findViewById<EditText>(R.id.editTextItemName)
        val qtyInput = findViewById<EditText>(R.id.editTextItemQuantity)
        val dateInput = findViewById<EditText>(R.id.editTextItemDate)
        val addBtn = findViewById<Button>(R.id.buttonAddItem)
        val recycler = findViewById<RecyclerView>(R.id.recyclerInventory)

        adapter = InventoryAdapter(items) { item ->
            db.deleteItem(item.id)
            loadItems()
        }

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        addBtn.setOnClickListener {
            db.addItem(
                nameInput.text.toString(),
                qtyInput.text.toString().toInt(),
                dateInput.text.toString()
            )
            loadItems()
        }

        loadItems()
    }

    private fun loadItems() {
        items.clear()
        val cursor = db.getAllItems()
        while (cursor.moveToNext()) {
            items.add(
                InventoryItem(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getInt(2),
                    cursor.getString(3)
                )
            )
        }
        cursor.close()
        adapter.notifyDataSetChanged()
    }
}
