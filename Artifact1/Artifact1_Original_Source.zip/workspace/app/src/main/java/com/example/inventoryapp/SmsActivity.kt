package com.example.inventoryapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class SmsActivity : AppCompatActivity() {

    private val SMS_PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)

        val statusText = findViewById<TextView>(R.id.textSmsStatus)
        val permissionBtn = findViewById<Button>(R.id.buttonRequestPermission)

        permissionBtn.setOnClickListener {
            requestSmsPermission(statusText)
        }
    }

    private fun requestSmsPermission(statusText: TextView) {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_CODE
            )
        } else {
            statusText.text = "Status: Permission already granted"
            sendTestSms()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        val statusText = findViewById<TextView>(R.id.textSmsStatus)

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED
            ) {
                statusText.text = "Status: Permission granted"
                sendTestSms()
            } else {
                statusText.text = "Status: Permission denied"
            }
        }
    }

    private fun sendTestSms() {
        try {
            val sms = SmsManager.getDefault()
            sms.sendTextMessage(
                "5551234567",   // Emulator test number
                null,
                "Inventory alert: Test notification",
                null,
                null
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
