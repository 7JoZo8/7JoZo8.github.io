package com.example.inventoryapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class InventoryAdapter(
    private val items: MutableList<InventoryItem>,
    private val onDelete: (InventoryItem) -> Unit
) : RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder>() {

    class InventoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.textItemName)
        val quantity: TextView = view.findViewById(R.id.textItemQuantity)
        val date: TextView = view.findViewById(R.id.textItemDate)
        val deleteBtn: Button = view.findViewById(R.id.buttonDeleteItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InventoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_inventory, parent, false)
        return InventoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: InventoryViewHolder, position: Int) {
        val item = items[position]
        holder.name.text = item.name
        holder.quantity.text = item.quantity.toString()
        holder.date.text = item.date

        holder.deleteBtn.setOnClickListener {
            onDelete(item)
        }
    }

    override fun getItemCount() = items.size
}
