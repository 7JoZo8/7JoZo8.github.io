package com.example.inventoryapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Handles storage and retrieval of user and inventory data
// from the application's local SQLite database.
class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "InventoryApp.db", null, 1) {

    // Creates the database tables when the application database
    // is initialized for the first time.
    override fun onCreate(db: SQLiteDatabase) {

        // Stores account information.
        // The password column now stores a hash instead of plaintext.
        db.execSQL(
            """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
            """.trimIndent()
        )

        // Stores inventory records entered by the user.
        db.execSQL(
            """
            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                date TEXT NOT NULL
            )
            """.trimIndent()
        )
    }

    // Recreates the application tables when the database version changes.
    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS inventory")
        onCreate(db)
    }

    // Creates a new user account using an already-hashed password.
    fun createUser(username: String, passwordHash: String): Boolean {
        val db = writableDatabase

        val values = ContentValues().apply {
            put("username", username)
            put("password", passwordHash)
        }

        val result = db.insert("users", null, values)

        return result != -1L
    }

    // Checks whether a username already exists in the database.
    fun userExists(username: String): Boolean {
        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT id FROM users WHERE username = ?",
            arrayOf(username)
        )

        val exists = cursor.moveToFirst()
        cursor.close()

        return exists
    }

    // Retrieves the stored password hash for a username.
    // Returns null if the account does not exist.
    fun getPasswordHash(username: String): String? {
        val db = readableDatabase

        val cursor = db.rawQuery(
            "SELECT password FROM users WHERE username = ?",
            arrayOf(username)
        )

        val passwordHash =
            if (cursor.moveToFirst()) {
                cursor.getString(0)
            } else {
                null
            }

        cursor.close()

        return passwordHash
    }

    // Adds a validated inventory item to the database.
    fun addItem(name: String, quantity: Int, date: String): Boolean {
        val db = writableDatabase

        val values = ContentValues().apply {
            put("name", name)
            put("quantity", quantity)
            put("date", date)
        }

        val result = db.insert("inventory", null, values)

        return result != -1L
    }

    // Returns all inventory records needed by the inventory screen.
    fun getAllItems() =
        readableDatabase.rawQuery(
            "SELECT id, name, quantity, date FROM inventory",
            null
        )

    // Deletes an inventory item using its unique database ID.
    fun deleteItem(id: Int) {
        writableDatabase.delete(
            "inventory",
            "id = ?",
            arrayOf(id.toString())
        )
    }
}