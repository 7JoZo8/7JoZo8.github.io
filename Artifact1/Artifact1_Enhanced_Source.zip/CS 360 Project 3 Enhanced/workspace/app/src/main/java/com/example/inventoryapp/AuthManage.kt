package com.example.inventoryapp

// Handles authentication separately from the user interface
// and database storage logic.
class AuthManage(private val db: DatabaseHelper) {

    // Validates account information and creates a new user.
    fun createAccount(username: String, password: String): String {

        // Do not allow empty account information.
        if (username.isBlank() || password.isBlank()) {
            return "Username and password are required"
        }

        // Require a minimum username length.
        if (username.length < 4) {
            return "Username must be at least 4 characters"
        }

        // Require a minimum password length.
        if (password.length < 8) {
            return "Password must be at least 8 characters"
        }

        // Prevent duplicate usernames.
        if (db.userExists(username)) {
            return "Username already exists"
        }

        // Hash the password before sending it to the database.
        val passwordHash = PasswordUtils.hashPassword(password)

        return if (db.createUser(username, passwordHash)) {
            "Account created"
        } else {
            "Unable to create account"
        }
    }

    // Verifies login information for an existing account.
    fun login(username: String, password: String): Boolean {

        // Do not attempt authentication with empty fields.
        if (username.isBlank() || password.isBlank()) {
            return false
        }

        // Retrieve the stored hash for the requested username.
        // If the account does not exist, login immediately fails.
        val storedPasswordHash =
            db.getPasswordHash(username) ?: return false

        // Compare the entered password with the stored password hash.
        return PasswordUtils.verifyPassword(
            password,
            storedPasswordHash
        )
    }
}