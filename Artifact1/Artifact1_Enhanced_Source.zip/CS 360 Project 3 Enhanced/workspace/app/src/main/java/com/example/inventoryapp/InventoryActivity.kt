package com.example.inventoryapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class InventoryActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: InventoryAdapter
    private val items = mutableListOf<InventoryItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)

        db = DatabaseHelper(this)

        val nameInput =
            findViewById<EditText>(R.id.editTextItemName)

        val qtyInput =
            findViewById<EditText>(R.id.editTextItemQuantity)

        val dateInput =
            findViewById<EditText>(R.id.editTextItemDate)

        val addBtn =
            findViewById<Button>(R.id.buttonAddItem)

        val recycler =
            findViewById<RecyclerView>(R.id.recyclerInventory)

        // Delete the selected inventory item and refresh the list.
        adapter = InventoryAdapter(items) { item ->
            db.deleteItem(item.id)
            loadItems()
        }

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        addBtn.setOnClickListener {

            val name =
                nameInput.text.toString().trim()

            val quantityText =
                qtyInput.text.toString().trim()

            val date =
                dateInput.text.toString().trim()

            // Require all fields before attempting to add an item.
            if (
                name.isBlank() ||
                quantityText.isBlank() ||
                date.isBlank()
            ) {
                Toast.makeText(
                    this,
                    "Please complete all inventory fields",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // Safely convert the quantity instead of allowing
            // invalid text to cause the application to crash.
            val quantity =
                quantityText.toIntOrNull()

            // Reject invalid or negative quantity values.
            if (quantity == null || quantity < 0) {
                Toast.makeText(
                    this,
                    "Please enter a valid quantity",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // Add the validated inventory item to SQLite.
            val success =
                db.addItem(
                    name,
                    quantity,
                    date
                )

            if (success) {
                Toast.makeText(
                    this,
                    "Item added",
                    Toast.LENGTH_SHORT
                ).show()

                // Clear the input fields after a successful insert.
                nameInput.text.clear()
                qtyInput.text.clear()
                dateInput.text.clear()

                // Reload the inventory so the new item appears immediately.
                loadItems()

            } else {
                Toast.makeText(
                    this,
                    "Unable to add item",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // Load the existing inventory when the screen first opens.
        loadItems()
    }

    // Reads the current inventory records from SQLite
    // and refreshes the RecyclerView.
    private fun loadItems() {
        items.clear()

        val cursor = db.getAllItems()

        while (cursor.moveToNext()) {
            items.add(
                InventoryItem(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getInt(2),
                    cursor.getString(3)
                )
            )
        }

        cursor.close()
        adapter.notifyDataSetChanged()
    }
}