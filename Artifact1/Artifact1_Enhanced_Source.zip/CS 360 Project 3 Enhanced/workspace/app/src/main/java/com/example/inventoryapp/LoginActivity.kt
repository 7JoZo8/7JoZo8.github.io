package com.example.inventoryapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    // Authentication is handled outside of the Activity
    // to keep UI and authentication responsibilities separate.
    private lateinit var authManage: AuthManage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Create the database helper and authentication manager.
        val db = DatabaseHelper(this)
        authManage = AuthManage(db)

        val username =
            findViewById<EditText>(R.id.editTextUsername)

        val password =
            findViewById<EditText>(R.id.editTextPassword)

        val loginBtn =
            findViewById<Button>(R.id.buttonLogin)

        val createBtn =
            findViewById<Button>(R.id.buttonCreateAccount)

        // Attempt to log in using the credentials entered by the user.
        loginBtn.setOnClickListener {

            val usernameText =
                username.text.toString().trim()

            val passwordText =
                password.text.toString()

            // Prevent empty login attempts.
            if (
                usernameText.isBlank() ||
                passwordText.isBlank()
            ) {
                Toast.makeText(
                    this,
                    "Please enter a username and password",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // AuthManage performs the actual password verification.
            if (
                authManage.login(
                    usernameText,
                    passwordText
                )
            ) {
                Toast.makeText(
                    this,
                    "Login successful",
                    Toast.LENGTH_SHORT
                ).show()

                // Open the inventory screen after successful login.
                startActivity(
                    Intent(
                        this,
                        InventoryActivity::class.java
                    )
                )

            } else {
                Toast.makeText(
                    this,
                    "Invalid username or password",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // Create a new user account using the entered credentials.
        createBtn.setOnClickListener {

            val usernameText =
                username.text.toString().trim()

            val passwordText =
                password.text.toString()

            // AuthManage validates the input and hashes the password
            // before it is stored in the database.
            val result =
                authManage.createAccount(
                    usernameText,
                    passwordText
                )

            Toast.makeText(
                this,
                result,
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}