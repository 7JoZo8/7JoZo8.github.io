package com.example.inventoryapp

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

// Handles password hashing and password verification.
// Passwords are never stored directly in the database.
object PasswordUtils {

    // Settings used to generate a secure PBKDF2 password hash.
    private const val ITERATIONS = 120000
    private const val KEY_LENGTH = 256
    private const val SALT_LENGTH = 16

    // Creates a random salt and hashes the user's password before storage.
    fun hashPassword(password: String): String {
        val salt = ByteArray(SALT_LENGTH)
        SecureRandom().nextBytes(salt)

        val hash = generateHash(password, salt)

        val encodedSalt = Base64.encodeToString(
            salt,
            Base64.NO_WRAP
        )

        val encodedHash = Base64.encodeToString(
            hash,
            Base64.NO_WRAP
        )

        // Store the salt and hash together so the same salt
        // can be used later when verifying the password.
        return "$encodedSalt:$encodedHash"
    }

    // Verifies a password entered during login against the stored hash.
    fun verifyPassword(
        password: String,
        storedPassword: String
    ): Boolean {

        val parts = storedPassword.split(":")

        // A valid stored password should contain both a salt and hash.
        if (parts.size != 2) {
            return false
        }

        return try {
            val salt = Base64.decode(
                parts[0],
                Base64.NO_WRAP
            )

            val storedHash = Base64.decode(
                parts[1],
                Base64.NO_WRAP
            )

            // Hash the entered password using the original salt.
            val enteredHash = generateHash(
                password,
                salt
            )

            // Compare the two hashes instead of comparing plaintext passwords.
            MessageDigest.isEqual(
                storedHash,
                enteredHash
            )

        } catch (e: Exception) {
            false
        }
    }

    // Generates a PBKDF2 hash using the password and provided salt.
    private fun generateHash(
        password: String,
        salt: ByteArray
    ): ByteArray {

        val spec = PBEKeySpec(
            password.toCharArray(),
            salt,
            ITERATIONS,
            KEY_LENGTH
        )

        return try {
            val factory = SecretKeyFactory.getInstance(
                "PBKDF2WithHmacSHA256"
            )

            factory.generateSecret(spec).encoded

        } finally {
            // Clear the password characters from memory after use.
            spec.clearPassword()
        }
    }
}