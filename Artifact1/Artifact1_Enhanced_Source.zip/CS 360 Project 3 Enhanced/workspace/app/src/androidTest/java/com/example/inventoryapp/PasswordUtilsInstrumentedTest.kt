package com.example.inventoryapp

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PasswordUtilsInstrumentedTest {

    @Test
    fun correctPasswordReturnsTrue() {
        val password = "TestPassword123"

        val storedPassword = PasswordUtils.hashPassword(password)

        val result = PasswordUtils.verifyPassword(
            password,
            storedPassword
        )

        assertTrue(result)
    }

    @Test
    fun incorrectPasswordReturnsFalse() {
        val password = "TestPassword123"
        val wrongPassword = "WrongPassword123"

        val storedPassword = PasswordUtils.hashPassword(password)

        val result = PasswordUtils.verifyPassword(
            wrongPassword,
            storedPassword
        )

        assertFalse(result)
    }

    @Test
    fun samePasswordCreatesDifferentStoredValues() {
        val password = "TestPassword123"

        val firstStoredPassword =
            PasswordUtils.hashPassword(password)

        val secondStoredPassword =
            PasswordUtils.hashPassword(password)

        assertNotEquals(
            firstStoredPassword,
            secondStoredPassword
        )
    }

    @Test
    fun invalidStoredPasswordFormatReturnsFalse() {
        val result = PasswordUtils.verifyPassword(
            "TestPassword123",
            "invalidStoredValue"
        )

        assertFalse(result)
    }
}