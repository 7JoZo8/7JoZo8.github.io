package com.example.inventoryapp

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AuthManageInstrumentedTest {

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var authManage: AuthManage

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()

        // Start each test with a clean database
        context.deleteDatabase("InventoryApp.db")

        databaseHelper = DatabaseHelper(context)
        authManage = AuthManage(databaseHelper)
    }

    @After
    fun tearDown() {
        databaseHelper.close()

        val context = ApplicationProvider.getApplicationContext<Context>()
        context.deleteDatabase("InventoryApp.db")
    }

    @Test
    fun createAccount_withValidCredentials_createsAccount() {
        val result = authManage.createAccount("testuser", "testpassword")

       assertEquals("Account created", result)
    }

    @Test
    fun createAccount_withDuplicateUsername_rejectsSecondAccount() {
        val firstResult = authManage.createAccount ("testuser", "testpassword")

        val secondResult = authManage.createAccount("testuser", "anotherpassword")

        assertEquals("Account created", firstResult)
        assertEquals("Username already exists", secondResult)
    }

    @Test
    fun login_withCorrectCredentials_returnsTrue() {
        authManage.createAccount("testuser", "testpassword")
        val loginResult = authManage.login("testuser", "testpassword")
        assertTrue(loginResult)
    }

    @Test
    fun login_withIncorrectPassword_returnsFalse() {
        authManage.createAccount("testuser", "testpassword")

        val loginResult = authManage.login("testuser", "wrongpassword")
        assertFalse(loginResult)
    }

    @Test
    fun login_withNonexistentUsername_returnsFalse() {
        val loginResult = authManage.login("nouser", "testpassword")
        assertFalse(loginResult)
    }

    @Test
    fun createAccount_withEmptyUsername_rejectsAccount() {
        val result = authManage.createAccount("", "testpassword")
        assertEquals("Username and password are required", result)
    }

    @Test
    fun createAccount_withShortUsername_rejectsAccount() {
        val result = authManage.createAccount("abc", "testpassword")
        assertEquals("Username must be at least 4 characters", result)
    }

    @Test
    fun createAccount_withShortPassword_rejectsAccount() {
        val result = authManage.createAccount("testuser", "short")
        assertEquals("Password must be at least 8 characters", result)
    }

    @Test
    fun login_withBlankCredentials_returnsFalase(){
        val loginResult = authManage.login("","")
        assertFalse(loginResult)
    }

}