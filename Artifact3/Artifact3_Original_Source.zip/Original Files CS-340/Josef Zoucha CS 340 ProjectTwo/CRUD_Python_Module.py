# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        USER = username  # use the username passed in
        PASS = password  # use the password passed in
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 

        try:
            self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}') 
            self.database = self.client[DB] 
            self.collection = self.database[COL]
        except Exception as e:
            print("Connection failed:", e)

    # Create a method to return the next available record number for use in the create method
    def get_next_id(self):
        try:
            # Find the document with the highest animal_id
            last_record = self.collection.find_one({}, sort=[("animal_id", -1)])
            if last_record and "animal_id" in last_record:
                # Extract digits only from animal_id
                digits = ''.join(filter(str.isdigit, last_record["animal_id"]))
                # If there are digits, increment; otherwise start at 1
                next_id = str(int(digits) + 1) if digits else "1"
                return next_id
            else:
                return "1"
        except Exception as e:
            print("Error getting ID:", e)
            return "1"
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        try:
            if data is not None:                    
                self.collection.insert_one(data)  # data should be dictionary
                return True
            else: 
                return False      
        except Exception as e:
            print("Create failed:", e)
            return False

    # Create method to implement the R in CRUD.
    def read(self, query):
        try:
            if query is not None:
                cursor = self.collection.find(query)
                result = list(cursor)
                return result
            else:
                return[]
        except Exception as e:
            print("Read failed:", e)
            return[]
    #Create method to implement the U in CRUD
    def update(self, query, new_values):
        try:
            if query is not None and new_values is not None:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            else:
                return 0
        except Exception as e:
            print("Update failed:", e)
            return 0
            
    #Create method to implement the D in CRUD
    def delete(self, query):
        try:
            if query is not None:
                result = self.collection.delete_many(query)
                return result.deleted_count
            else:
                return 0
        except Exception as e:
            print("Delete failed:", e)
            return 0