# CS-340
Final Journal

How do you write programs that are maintainable, readable, and adaptable? Especially consider your work on the CRUD Python module from Project One, which you used to connect the dashboard widgets to the database in Project Two. What were the advantages of working in this way? How else could you use this CRUD Python module in the future?

How do you approach a problem as a computer scientist? Consider how you approached the database or dashboard requirements that Grazioso Salvare requested. How did your approach to this project differ from previous assignments in other courses? What techniques or strategies would you use in the future to create databases to meet other client requests?

What do computer scientists do, and why does it matter? How would your work on this type of project help a company, like Grazioso Salvare, to do their work better?


In the development cycle of this project, I focused on writing code that was maintainable, readable, and adaptable by organizing it into clear components and reusing functionality. A main example of this is the CRUD Python Module that was developed for Project One and used again for Project Two to connect the dashboard to the MongoDB database. Database logic was separated from the dashboard interface, and my code was more modular and easier to manage thanks to my approach. Debugging and updates were also made more efficient due to my approach. In the future, it's possible to reuse my CRUD module in other applications that require database interaction, which would save time and improve consistency across upcoming projects.

I began working through the requirements step by step when I first approached this project, starting with the database and ending with the dashboard. This project required more integration between components, including the database, backend logic, and user interface, compared to previous assignments. I used a structured approach, testing each feature as I built it, breaking the problem down into smaller, more manageable parts, and then refining my code based on the errors produced. In the future, I will be continuing to use this approach and focus on designing flexible databases that can adapt to other client needs.

Computer scientists develop systems that solve real-world problems. This project gives an example of how software can support decision-making. I created a tool that allows Grazioso Salvare to efficiently filter and analyze animal data to identify suitable dogs for rescue training. This will improve their ability to make informed decisions quickly, which will help them carry out their mission more effectively in the end.
