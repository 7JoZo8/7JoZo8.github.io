from pymongo import MongoClient


class AnimalShelter:
    """Provide CRUD operations and search support for the animal collection."""

    def __init__(self):
        """Connect to the local MongoDB database and prepare search indexes."""
        database_name = "aac"
        collection_name = "animals"

        try:
            self.client = MongoClient("mongodb://localhost:27017")
            self.database = self.client[database_name]
            self.collection = self.database[collection_name]

            # Create indexes used by dashboard search functionality
            self.create_search_indexes()

        except Exception as e:
            print("Connection failed:", e)

    def get_next_id(self):
        """Return the next available numeric animal ID."""
        try:
            last_record = self.collection.find_one(
                {},
                sort=[("animal_id", -1)]
            )

            if last_record and "animal_id" in last_record:
                digits = "".join(
                    filter(str.isdigit, last_record["animal_id"])
                )
                return str(int(digits) + 1) if digits else "1"

            return "1"

        except Exception as e:
            print("Error getting ID:", e)
            return "1"

    def create(self, data):
        """Insert a new animal record."""
        try:
            if data is None:
                return False

            self.collection.insert_one(data)
            return True

        except Exception as e:
            print("Create failed:", e)
            return False

    def read(self, query):
        """Return animal records that match the supplied MongoDB query."""
        try:
            if query is None:
                return []

            return list(self.collection.find(query))

        except Exception as e:
            print("Read failed:", e)
            return []

    def build_search_query(
        self,
        animal_type=None,
        breed=None,
        sex=None,
        min_age=None,
        max_age=None
    ):
        """Build a MongoDB query from optional animal search criteria."""
        query = {}

        if animal_type:
            query["animal_type"] = animal_type

        if breed:
            query["breed"] = breed

        if sex:
            query["sex_upon_outcome"] = sex

        if min_age is not None or max_age is not None:
            age_query = {}

            if min_age is not None:
                age_query["$gte"] = min_age

            if max_age is not None:
                age_query["$lte"] = max_age

            query["age_upon_outcome_in_weeks"] = age_query

        return query

    def search_animals(
        self,
        animal_type=None,
        breed=None,
        sex=None,
        min_age=None,
        max_age=None
    ):
        """Search animal records using optional criteria."""
        query = self.build_search_query(
            animal_type=animal_type,
            breed=breed,
            sex=sex,
            min_age=min_age,
            max_age=max_age
        )

        return self.read(query)

    def create_search_indexes(self):
        """Create indexes for fields commonly used by dashboard searches."""
        try:
            self.collection.create_index("animal_type")
            self.collection.create_index("breed")
            self.collection.create_index("sex_upon_outcome")
            self.collection.create_index("age_upon_outcome_in_weeks")
            return True

        except Exception as e:
            print("Index creation failed:", e)
            return False

    def update(self, query, new_values):
        """Update animal records that match the supplied query."""
        try:
            if query is None or new_values is None:
                return 0

            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )
            return result.modified_count

        except Exception as e:
            print("Update failed:", e)
            return 0

    def delete(self, query):
        """Delete animal records that match the supplied query."""
        try:
            if query is None:
                return 0

            result = self.collection.delete_many(query)
            return result.deleted_count

        except Exception as e:
            print("Delete failed:", e)
            return 0