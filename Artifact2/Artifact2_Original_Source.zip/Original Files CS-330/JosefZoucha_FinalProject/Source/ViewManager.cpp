///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

//forward declaration of scroll camera speed function for callback
void ScrollCallback(GLFWwindow* window, double xoffset, double yoffset);


// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;

	//flase by default true when there is a perspective view
	bool bPerspectiveProjection = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;
	g_pCamera->MovementSpeed = 20;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	//this callback is used to adjust camera speed with the mouse scroll wheel
	glfwSetScrollCallback(window, ScrollCallback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// when the first mouse move event is received, this needs to be recorded so that
	// all subsequent mouse moves can correctly calculate the X position offset and Y
	// position offset for proper operation
	if (gFirstMouse)
	{
		gLastX = xMousePos;
		gLastY = yMousePos;
		gFirstMouse = false;
	}

	// calculate the X offset and Y offset values for moving the 3D camera accordingly
	float xOffset = xMousePos - gLastX;
	float yOffset = gLastY - yMousePos; // reversed since y-coordinates go from bottom to top

	// set the current positions into the last position variables
	gLastX = xMousePos;
	gLastY = yMousePos;

	// move the 3D camera according to the calculated offsets
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// process camera zooming in and out
	//camera zoom in with W key
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	//camera zoom out with S key
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// process camera panning left and right
	//camera pan left with A key
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	//camera pan right with D key
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	//process camera moving up and down
	//camera move up with Q key
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	//camera move down with E key
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}

	//orthographic projection view
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		bOrthographicProjection = true;
		bPerspectiveProjection = false;
	}

	//perspective projection view
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		bPerspectiveProjection = true;
		bOrthographicProjection = false;
	}
}

/***********************************************************
 *  ScrollCallback()
 *
 *  This method will allow the scroll wheel
 *	to modify the camera speed.
 ***********************************************************/
	void ScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
 {
	 if (g_pCamera != nullptr)
	 {
		 //adjust camera speed with scroll
		 g_pCamera->MovementSpeed += static_cast<float>(yoffset);
		 //clamp movement speed to avoid extreme values
		 if (g_pCamera->MovementSpeed < 1.0f)
			 g_pCamera->MovementSpeed = 1.0f;
		 if (g_pCamera->MovementSpeed > 50.0f)
			 g_pCamera->MovementSpeed = 50.0f;
	 }
 }

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	//set viewport to entire window
	glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);

	if (bOrthographicProjection == true)
	{
		

		//table's rotation 
		float planeYRotation = 23.0f;

		//center of plane
		glm::vec3 planeCenter(0.0f, 0.0f, 0.0f);

		//distance from plane
		float distance = 20.0f;

		//compute negative rotation to counter table rotation
		float angleYRad = glm::radians(-planeYRotation);
		glm::vec3 initialCamOffset(0.0f, 0.0f, distance);
		glm::mat4 rotCorrection = glm::rotate(angleYRad, glm::vec3(0.0f, 1.0f, 0.0f));
		glm::vec3 orthoCameraPos = glm::vec3(rotCorrection * glm::vec4(initialCamOffset, 1.0f)) + planeCenter;

		//camera looks at center of plane
		glm::vec3 orthoTarget = planeCenter;

		//standard up vector
		glm::vec3 orthoUp = glm::vec3(0.0f, 1.0f, 0.0f);

		//view matrix
		view = glm::lookAt(orthoCameraPos, orthoTarget, orthoUp);

		//use glOrtho to set projection
		float aspect = (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT;
		float halfHeight = 10.0f;
		float halfWidth = halfHeight * aspect;
		projection = glm::ortho(-halfWidth, halfWidth, -halfHeight, halfHeight, 0.1f, 100.0f);
	}

	else if (bPerspectiveProjection == true)
	{


		//table's rotation 
		float planeYRotation = 23.0f;

		//center of the table
		glm::vec3 planeCenter(1.5f, 0.0f, 0.0f);

		//distance and height from table
		float distance = 20.0f;
		float height = 8.0f;

		//compute rotation to match table orientation
		float angleYRad = glm::radians(planeYRotation);
		glm::vec3 initialCamOffset(0.0f, height, distance);
		glm::mat4 rotCorrection = glm::rotate(angleYRad, glm::vec3(0.0f, 1.0f, 0.0f));
		glm::vec3 perspectiveCameraPos = glm::vec3(rotCorrection * glm::vec4(initialCamOffset, 1.0f)) + planeCenter;

		//camera looks at center of the table
		glm::vec3 perspectiveTarget = planeCenter;

		//standard up vector
		glm::vec3 perspectiveUp(0.0f, 1.0f, 0.0f);

		//set view matrix
		view = glm::lookAt(perspectiveCameraPos, perspectiveTarget, perspectiveUp);

		//set perspective projection
		projection = glm::perspective(glm::radians(45.0f),
			(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
			0.1f, 100.0f);
	}
	else
	{
			view = g_pCamera->GetViewMatrix();
		projection = glm::perspective(glm::radians(g_pCamera->Zoom),
			(GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT,
			0.1f, 100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}