///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);



		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}
/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
  *  DefineObjectMaterials()
  *
  *  This method is used for configuring the various material
  *  settings for all of the objects within the 3D scene.
  ***********************************************************/

void SceneManager::DefineObjectMaterials()
{
	//define materials for objects
	//wood for table
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.9f, 0.9f, 0.9f);
	woodMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.shininess = 32.0f;
	woodMaterial.tag = "wood";

	m_objectMaterials.push_back(woodMaterial);




	//cardboard for pasta box
	OBJECT_MATERIAL cardboardMaterial;
	cardboardMaterial.diffuseColor = glm::vec3(0.255f, 0.412f, 0.882f);
	cardboardMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	cardboardMaterial.shininess = 8.0f;
	cardboardMaterial.tag = "cardboard";

	m_objectMaterials.push_back(cardboardMaterial);


	//metal for pot
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.diffuseColor = glm::vec3(0.502, 0.502, 0.502);
	metalMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.85f);
	metalMaterial.shininess = 96.0f;
	metalMaterial.tag = "metal";

	m_objectMaterials.push_back(metalMaterial);


	//glass for jar
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.627f, 0.322f, 0.176f);
	glassMaterial.specularColor = glm::vec3(0.15f, 0.15f, 0.18f);
	glassMaterial.shininess = 24.0f;
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);
	

	

	//silicon for spoon
	OBJECT_MATERIAL siliconMaterial;
	siliconMaterial.diffuseColor = glm::vec3(0.180f, 0.545f, 0.341); //possible color change (0.0f, 0.5f, 0.4f)
	siliconMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	siliconMaterial.shininess = 16.0f;
	siliconMaterial.tag = "silicon";

	m_objectMaterials.push_back(siliconMaterial);

	//metal for sauce jar lid
	OBJECT_MATERIAL lidMaterial;
	lidMaterial.diffuseColor = glm::vec3(0.0f, 0.392f, 0.0f);
	lidMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.85f);
	lidMaterial.shininess = 32.0f;
	lidMaterial.tag = "lidMetal";

	m_objectMaterials.push_back(lidMaterial);

}



/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	//needed line to tell shaders to render custom lighting in the scene
	m_pShaderManager->setBoolValue(g_UseLightingName, true);


	//setup light sources
	//directional light - warm yellow main light
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.6f, -0.8f, -0.4f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.45f, 0.40f, 0.30f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.9f, 0.8f, 0.5f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.6f, 0.55f, 0.4f);

	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	//point light - cool cyan accent
	m_pShaderManager->setVec3Value("pointLights[0].position", 1.5f, 3.0f, 1.5f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.05f, 0.1f, 0.15f);     
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.2f, 0.5f, 0.8f);      
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.3f, 0.6f, 0.9f);     
	m_pShaderManager->setFloatValue("pointLights[0].constant", 1.0f);
	m_pShaderManager->setFloatValue("pointLights[0].linear", 0.07f);
	m_pShaderManager->setFloatValue("pointLights[0].quadratic", 0.017f);

	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	

}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
*	LoadSceneTextures()
*
*	This method will load textures
*	for shapes in memory
*	to support 3D rendering
***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	//sample texture
	bReturn = CreateGLTexture(
		"textures/sample_texture.jpg",
		"test");

	//wood texture
	bReturn = CreateGLTexture(
		"textures/wood.jpg",
		"wood");

	//sauce jar lid texture
	bReturn = CreateGLTexture(
		"textures/jar_lid.jpg",
		"jar_lid");

	//sauce jar top
	bReturn = CreateGLTexture(
		"textures/jar_top.jpg",
		"jar_top");

	//spoon texture
	bReturn = CreateGLTexture(
		"textures/spoon.jpg",
		"spoon");

	//back of pasta box
	bReturn = CreateGLTexture(
		"textures/box_back.jpg",
		"box_back");

	//front of pasta box
	bReturn = CreateGLTexture(
		"textures/box_front.jpg",
		"box_front");

	//the box's left side
	bReturn = CreateGLTexture(
		"textures/box_right.jpg",
		"box_right");

	//top of pasta box
	bReturn = CreateGLTexture(
		"textures/box_top.jpg",
		"box_top");

	//plain background to be used for 
	// the box's right side and bottom
	bReturn = CreateGLTexture(
		"textures/box_plain.jpg",
		"box_plain");

	//metal pot texture
	bReturn = CreateGLTexture(
		"textures/metal_pot.jpg",
		"metal_pot");

	//metal pot top texture
	bReturn = CreateGLTexture(
		"textures/pot.jpg",
		"pot_top");

	//backdrop texture
	bReturn = CreateGLTexture(
		"textures/backdrop_texture.jpg",
		"backdrop");


	//sauce jar label
	bReturn = CreateGLTexture(
		"textures/sauce.jpg",
		"sauce");

	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();

	SetupSceneLights();



	DefineObjectMaterials();
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	//pasta sauce torus
	m_basicMeshes->LoadTorusMesh(0.1);
	//metal pot lip torus
	m_basicMeshes->LoadExtraTorusMesh1(0.05);
	//silicon spoon edge torus
	m_basicMeshes->LoadExtraTorusMesh2(0.15);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/


	//Start 3D object replication
	/*------------------------------------------------------------------*/
	//*********************BACKDROP_PLANE******************************
	
		//set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(20.0f, 20.0f, 20.0f);

		//set the rotation
		XrotationDegrees = 90.0f;
		YrotationDegrees = 23.0f;
		ZrotationDegrees = 0.0f;

		//set the XYZ position for the mesh
		positionXYZ = glm::vec3(0.0f, 0.0f, -4.0f);

		//set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		//placeholder color
		//set color values
		//SetShaderColor(1.0, 0.843, 0.0, 1);
		SetShaderMaterial("wood");
		//set backdrop texture
		SetShaderTexture("backdrop");
		//draw the mesh with transformative values
		m_basicMeshes->DrawPlaneMesh();

	//*********************BACKDROP_PLANE*********************************


	/*------------------------------------------------------------------*/


	//*********************TABLE******************************************
		
		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(18.0f, 0.35f, 8.0f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 23.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(2.0f, 0.0f, 0.0f);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		//set wood material for table
		SetShaderMaterial("wood");

		//placeholder color
		//SetShaderColor(1, 1, 1, 1);
		//set wood texture
		SetShaderTexture("wood");
		// draw the mesh with transformation values
		m_basicMeshes->DrawBoxMesh();

	//***************************TABLE************************************


	/*------------------------------------------------------------------*/


	//**********************PASTA_BOX*************************************
	
		//set the scale
		scaleXYZ = glm::vec3(4.0f, 5.0f, 2.0f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(4.2f, 2.69f, -2.0f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//set shader material
		SetShaderMaterial("cardboard");

		//set texture values
		SetShaderTexture("box_front");
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_front);

		SetShaderTexture("box_plain");
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_bottom);
		
		SetShaderTexture("box_back");
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_back);

		SetShaderTexture("box_top");
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_top);

		SetShaderTexture("box_plain");
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_left);

		SetShaderTexture("box_right");
		m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_right);
		
	//**********************PASTA_BOX*************************************


	/*------------------------------------------------------------------*/


	//**********************SAUCE_JAR*************************************

		//Main Jar Body
		//set the scale
		scaleXYZ = glm::vec3(1.3f, 3.8f, 1.3f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 100.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(8.5f, 0.18f, -2.0f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		
		//set color value
		//sienna
		//SetShaderColor(0.627, 0.322, 0.176, 1.0);
		//set shader texture
		SetShaderTexture("sauce");
		//set shader material
		SetShaderMaterial("glass");
		//draw mesh with transformation values
		m_basicMeshes->DrawCylinderMesh(false, false, true);




		//Bottom Lip of Jar
		//set the scale
		scaleXYZ = glm::vec3(1.3f, 3.0f, 1.3f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(8.5f, 0.48f, -2.0f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		
		//set color value
		//sienna
		SetShaderColor(0.627, 0.322, 0.176, 1);
		//set shader material
		SetShaderMaterial("glass");
		//draw mesh with transformation values
		m_basicMeshes->DrawTorusMesh();




		//Top Taperd part of jar
		//set the scale
		scaleXYZ = glm::vec3(1.3f, 0.8f, 1.3f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(8.5f, 3.98f, -2.0f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//set color value
		//sienna
		SetShaderColor(0.627, 0.322, 0.176, 0.85);
		//set shader material
		SetShaderMaterial("glass");
		//draw mesh with transformation values
		m_basicMeshes->DrawTaperedCylinderMesh();




		//Sauce Jar Lid
		//set the scale
		scaleXYZ = glm::vec3(1.0f, 0.25f, 1.0f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(8.5f, 4.68f, -2.0f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//placeholder color
		//set color value
		//dark green
		//SetShaderColor(0.0, 0.392, 0.0, 1);
		//set shader material
		SetShaderMaterial("lidMetal");
		//set shader texture
		SetShaderTexture("jar_lid");
		//draw mesh with transforamtion values
		m_basicMeshes->DrawCylinderMesh(false, true, true);




		//Sauce Jar lid top
		//set the scale
		scaleXYZ = glm::vec3(1.0f, 0.25f, 1.0f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(8.5f, 4.68f, -2.0f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//placeholder color
		//set color value
		//dark green
		//SetShaderColor(0.0, 0.392, 0.0, 1);
		//set shader material
		SetShaderMaterial("lidMetal");
		//set shader texture
		SetShaderTexture("jar_top");
		//draw mesh with transforamtion values
		m_basicMeshes->DrawCylinderMesh(true, false, false);

	//**********************SAUCE_JAR*************************************


	/*------------------------------------------------------------------*/


	//**********************METAL_POT*************************************
	

		//main pot body interior
		//set the scale
		scaleXYZ = glm::vec3(2.5f, 2.5f, 2.5f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-3.5f, 0.185f, 2.5f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("pot_top");
		m_basicMeshes->DrawCylinderMesh(false, true, false);




		//main pot body
		//set the scale
		scaleXYZ = glm::vec3(2.5f, 2.5f, 2.5f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-3.5f, 0.185f, 2.5f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("metal_pot");
		m_basicMeshes->DrawCylinderMesh(false, true, true);




		//pot upper lip
		//set the scale
		scaleXYZ = glm::vec3(2.72f, 0.2f, 2.72f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-3.5f, 2.685f, 2.5f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("metal_pot");
		m_basicMeshes->DrawCylinderMesh(false, false, true);




		//upper lip and metal pot body connector
		//set the scale
		scaleXYZ = glm::vec3(2.6f, 0.0f, 2.6f);

		//set the rotations
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-3.5f, 2.685f, 2.5f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("metal_pot");
		m_basicMeshes->DrawExtraTorusMesh1();




		//pot screw(L1)
		//set the scale
		scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);

		//set the rotations
		XrotationDegrees = 90.0f;
		YrotationDegrees = 109.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-5.85f, 2.0f, 3.3f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("metal_pot");
		m_basicMeshes->DrawHalfSphereMesh();




		//pot screw(L2)
		//set the scale
		scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);

		//set the rotations
		XrotationDegrees = 90.0f;
		YrotationDegrees = 155.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-4.55f, 2.0f, 4.75f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("metal_pot");
		m_basicMeshes->DrawHalfSphereMesh();





		//pot screw(R1)
		//set the scale
		scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);

		//set the rotations
		XrotationDegrees = 90.0f;
		YrotationDegrees = -40.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-2.05f, 2.0f, 0.5f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("metal_pot");
		m_basicMeshes->DrawHalfSphereMesh();




		//pot screw(R2)
		//set the scale
		scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);

		//set the rotations
		XrotationDegrees = 90.0f;
		YrotationDegrees = -80.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-1.05f, 2.0f, 2.2f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("metal_pot");
		m_basicMeshes->DrawHalfSphereMesh();




		//pot handle (left side of scene)
		//set the scale
		scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f);

		//set the rotations
		XrotationDegrees = -14.0f;
		YrotationDegrees = -47.50f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-5.15f, 2.0f, 3.95f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("metal_pot");
		m_basicMeshes->DrawHalfTorusMesh();




		//pot handle (right side of scene)
		//set the scale
		scaleXYZ = glm::vec3(1.0f, 2.0f, 1.0f);

		//set the rotations
		XrotationDegrees = -14.0f;
		YrotationDegrees = 119.0f;
		ZrotationDegrees = 0.0f;

		//set the position
		positionXYZ = glm::vec3(-1.6f, 2.0f, 1.4f);

		//set the transformations in to memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//placeholder color value
		//set color value
		//SetShaderColor(0.502, 0.502, 0.502, 1);
		//set shader material
		SetShaderMaterial("metal");
		//set texture value
		SetShaderTexture("metal_pot");
		m_basicMeshes->DrawHalfTorusMesh();

	//**********************METAL_POT*************************************


	/*------------------------------------------------------------------*/


	//**********************SILICON_SPOON*********************************

	//inner main spoon body
		//set the scale
		scaleXYZ = glm::vec3(0.7f, 0.55f, 1.2f);

		//set the rotations
		XrotationDegrees = 180.0f;
		YrotationDegrees = 80.0f;
		ZrotationDegrees = 0.0f;

		//set the position 
		positionXYZ = glm::vec3(0.40f, 0.73f, 0.2f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//set shader material
		SetShaderMaterial("silicon");
		//set shader texture
		SetShaderTexture("spoon");
		m_basicMeshes->DrawHalfSphereMesh();




		//outer main spoon body
		//set the scale
		scaleXYZ = glm::vec3(0.9f, 0.55f, 1.4f);

		//set the rotations
		XrotationDegrees = 180.0f;
		YrotationDegrees = 80.0f;
		ZrotationDegrees = 0.0f;

		//set the position 
		positionXYZ = glm::vec3(0.40f, 0.73f, 0.2f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//set shader material
		SetShaderMaterial("silicon");
		//set shader texture
		SetShaderTexture("spoon");
		m_basicMeshes->DrawHalfSphereMesh();




		//spoon lip
		//set the scale
		scaleXYZ = glm::vec3(0.8f, 0.55f, 1.3f);

		//set the rotations
		XrotationDegrees = 180.0f;
		YrotationDegrees = 80.0f;
		ZrotationDegrees = 0.0f;

		//set the position 
		positionXYZ = glm::vec3(0.40f, 0.73f, 0.2f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//set shader material
		SetShaderMaterial("silicon");
		//set shader texture
		SetShaderTexture("spoon");
		m_basicMeshes->DrawExtraTorusMesh2();




		//main spoon handle
		//set the scale
		scaleXYZ = glm::vec3(0.18f, 4.0f, 0.18f);

		//set the rotations
		XrotationDegrees = 92.0f;
		YrotationDegrees = 80.0f;
		ZrotationDegrees = 0.0f;

		//set the position 
		positionXYZ = glm::vec3(1.48f, 0.6f, 0.5f);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//set shader material
		SetShaderMaterial("silicon");
		//set shader texture
		SetShaderTexture("spoon");
		m_basicMeshes->DrawCylinderMesh(false, false, true);




		//end of spoon handle
		//set the scale
		scaleXYZ = glm::vec3(0.18f, 1.6f, 0.18f);

		//set the rotations
		XrotationDegrees = 12.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = -96.0f;

		//set the position 
		positionXYZ = glm::vec3(5.4f, 0.465f, 1.195);

		//set the transformations into memory
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);


		//set shader material
		SetShaderMaterial("silicon");
		//set shader texture
		SetShaderTexture("spoon");
		m_basicMeshes->DrawTaperedCylinderMesh();

	//**********************SILICON_SPOON*********************************
}